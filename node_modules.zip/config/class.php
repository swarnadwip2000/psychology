<?php
return [
    'school_class' => [
        1 => 'Grade XI',
        2 => 'Grade XII',
    ],
    'college_class' => [
        1 => 'Grade XI',
        2 => 'Grade XII',
    ],
    'allow_country' => [
        1 => 'CANADA',
    ],
    'fuclaty_degree'=>[
        1=> "Graduate",
        2=> "Post graduate",
        3=> "M-phil",
        4=> "Doctorate",

    ],
    'dropdown_country' => [
        [
            'id' => 1,
            'name' => "CANADA",
        ],
    ],

    'dropdown_school_class' => [
        [
            'id' => 1,
            'name' => "Grade XI",
        ],
        [
            'id' => 2,
            'name' => "Grade XII",
        ],
    ],


    'dropdown_fuclaty_degree' => [
        [
            'id' => 1,
            'name' => "Graduate",
        ],
        [
            'id' => 2,
            'name' => "Post graduate",
        ],
        [
            'id' => 3,
            'name' => "M-phil",
        ],
        [
            'id' => 4,
            'name' => "Doctorate",
        ],
    ],
];
