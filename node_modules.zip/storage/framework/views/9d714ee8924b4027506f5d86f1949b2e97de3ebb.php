
<?php $__env->startSection('title'); ?>
    <?php echo e(env('APP_NAME')); ?> | Edit Student Details
<?php $__env->stopSection(); ?>
<?php $__env->startPush('styles'); ?>
<?php $__env->stopPush(); ?>
<?php $__env->startSection('head'); ?>
    Edit Student Details
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="main-content">
        <div class="inner_page">
            <div class="card search_bar sales-report-card">
                <div class="sales-report-card-wrap">
                    <div class="form-head">
                        <h4>Login Information</h4>
                    </div>
                    <form action="<?php echo e(route('students.update', $student->id)); ?>" method="POST" enctype="multipart/form-data">
                        <?php echo method_field('PUT'); ?>
                        <?php echo csrf_field(); ?>
                        <div class="row justify-content-between">
                            <div class="col-md-6">
                                <div class="form-group-div">
                                    <div class="form-group">
                                        <label for="floatingInputValue">Email Address*</label>
                                        <input type="text" class="form-control" id="floatingInputValue" name="email"
                                            value="<?php echo e(old('email', $student->email)); ?>" placeholder="Email Address*">
                                        <?php if($errors->has('email')): ?>
                                            <div class="error" style="color:red;"><?php echo e($errors->first('email')); ?></div>
                                        <?php endif; ?>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group-div">
                                    <div class="form-group">
                                        <label for="floatingInputValue">Mobile*</label>
                                        <input type="text" class="form-control" id="floatingInputValue" name="phone"
                                            value="<?php echo e(old('phone', $student->phone)); ?>" placeholder="Mobile*">
                                        <?php if($errors->has('phone')): ?>
                                            <div class="error" style="color:red;"><?php echo e($errors->first('phone')); ?></div>
                                        <?php endif; ?>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group-div">
                                    <div class="form-group">
                                        <label for="floatingInputValue">Password*</label>
                                        <input type="password" class="form-control" id="password" name="password"
                                            value="<?php echo e(old('password')); ?>" placeholder="Password*">
                                        <span class="eye-btn-1" id="eye-button-1">
                                            <i class="ph ph-eye-slash" aria-hidden="true" id="togglePassword"></i>
                                        </span>
                                        <?php if($errors->has('password')): ?>
                                            <div class="error" style="color:red;"><?php echo e($errors->first('password')); ?></div>
                                        <?php endif; ?>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group-div">
                                    <div class="form-group">
                                        <label for="floatingInputValue">Confirm Password*</label>
                                        <input type="password" class="form-control" id="confirm_password"
                                            name="confirm_password" value="<?php echo e(old('confirm_password')); ?>"
                                            placeholder="Confirm Password*">
                                        <span class="eye-btn-1" id="eye-button-2">
                                            <i class="ph ph-eye-slash" aria-hidden="true" id="togglePassword"></i>
                                        </span>
                                        <?php if($errors->has('confirm_password')): ?>
                                            <div class="error" style="color:red;"><?php echo e($errors->first('confirm_password')); ?></div>
                                        <?php endif; ?>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div class="sales-report-card-wrap mt-5">
                            <div class="form-head">
                                <h4>Personal Information</h4>
                            </div>

                            <div class="row">
                                <div class="col-xl-4 col-md-6">
                                    <div class="form-group-div">
                                        <div class="form-group">
                                            <label for="floatingInputValue">Full Name*</label>
                                            <input type="text" class="form-control" id="floatingInputValue"
                                                name="name" value="<?php echo e(old('name', $student->name)); ?>" placeholder="Full Name*">
                                            <?php if($errors->has('name')): ?>
                                                <div class="error" style="color:red;"><?php echo e($errors->first('name')); ?></div>
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                </div>

                                
                                <div class="col-xl-4 col-md-6">
                                    <div class="form-group-div">
                                        <div class="form-group">
                                            <label for="floatingInputValue">Country*</label>
                                            <select id="country_id" name="country_id" class="form-control">
                                                <option value="">Select Country</option>
                                                <?php $__currentLoopData = $countries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $country): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <option value="<?php echo e($country->id); ?>" <?php echo e(old('country_id', $student->country_id) == $country->id ? 'selected' : ''); ?>>
                                                        <?php echo e($country->name); ?>

                                                    </option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </select>
                                            <?php if($errors->has('country_id')): ?>
                                                <div class="error" style="color:red;"><?php echo e($errors->first('country_id')); ?></div>
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                </div>

                                
                                <div class="col-xl-4 col-md-6">
                                    <div class="form-group-div">
                                        <div class="form-group">
                                            <label for="floatingInputValue">City*</label>
                                            <select id="city_id" name="city_id" class="form-control">
                                                <option value="">Select City</option>
                                                
                                            </select>
                                            <?php if($errors->has('city_id')): ?>
                                                <div class="error" style="color:red;"><?php echo e($errors->first('city_id')); ?></div>
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                </div>

                                <div class="col-md-6">
                        <div class="form-group-div">
                            <div class="form-group">
                                <label for="floatingInputValue">Address*</label>
                                <input type="text" class="form-control" id="floatingInputValue"
                                    name="address" value="<?php echo e(old('address', $student->address)); ?>" placeholder="Address*">
                                <?php if($errors->has('address')): ?>
                                    <div class="error" style="color:red;"><?php echo e($errors->first('address')); ?></div>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="form-group-div">
                            <div class="form-group">
                                <label for="floatingInputValue">School Name*</label>
                                <input type="text" class="form-control" id="floatingInputValue"
                                    name="institute_name" value="<?php echo e(old('institute_name', $student->institute_name)); ?>"
                                    placeholder="School Name*">
                                <?php if($errors->has('institute_name')): ?>
                                    <div class="error" style="color:red;"><?php echo e($errors->first('institute_name')); ?></div>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                    <div class="col-xl-6 col-md-6">
                        <div class="form-group-div">
                            <div class="form-group">
                                <label for="floatingInputValue">Age*</label>
                                <select name="student_age" id="student_age" class="form-control">
                                    <option value="">Select Age</option>
                                    <?php for($i = 20; $i < 45; $i++): ?>
                                        <option value="<?php echo e($i); ?>" <?php echo e(old('student_age', $student->student_age) == $i ? 'selected' : ''); ?>>
                                            <?php echo e($i); ?>

                                        </option>
                                    <?php endfor; ?>
                                </select>
                                <?php if($errors->has('student_age')): ?>
                                    <div class="error" style="color:red;"><?php echo e($errors->first('student_age')); ?></div>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>

                    <div class="col-xl-6 col-md-6">
                        <div class="form-group-div">
                            <div class="form-group">
                                <label for="floatingInputValue">Register As*</label>
                                <select name="register_as" id="register_as" class="form-control">
                                    <option value="">Select Register As</option>
                                    <option value="1" <?php echo e(old('register_as', $student->register_as) == 1 ? 'selected' : ''); ?>>School</option>
                                    <option value="2" <?php echo e(old('register_as', $student->register_as) == 2 ? 'selected' : ''); ?>>Collage</option>
                                </select>
                                <?php if($errors->has('register_as')): ?>
                                    <div class="error" style="color:red;"><?php echo e($errors->first('register_as')); ?></div>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                    <div class="col-xl-6 col-md-6">
                        <div class="form-group-div">
                            <div class="form-group">
                                <label for="floatingInputValue">Student Class*</label>
                                <select name="student_class" id="student_class" class="form-control">
                                    <option value="">Select Student Class</option>
                                    <?php $__currentLoopData = config('class.school_class'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($key); ?>" <?php echo e(old('student_class', $student->student_class) == $key ? 'selected' : ''); ?>>
                                            <?php echo e($val); ?>

                                        </option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                                <?php if($errors->has('student_class')): ?>
                                    <div class="error" style="color:red;"><?php echo e($errors->first('student_class')); ?></div>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                    <div class="col-xl-6 col-md-6">
                        <div class="form-group-div">
                            <div class="form-group">
                                <label for="floatingInputValue">Status*</label>
                                <select name="status" id="status" class="form-control">
                                    <option value="">Select Status</option>
                                    <option value="1" <?php echo e(old('status', $student->status) == 1 ? 'selected' : ''); ?>>Active</option>
                                    <option value="0" <?php echo e(old('status', $student->status) == 0 ? 'selected' : ''); ?>>Inactive</option>
                                </select>
                                <?php if($errors->has('status')): ?>
                                    <div class="error" style="color:red;"><?php echo e($errors->first('status')); ?></div>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>

                            </div>
                        </div>

                        <div class="col-xl-12">
                            <div class="btn-1">
                                <button type="submit">Update</button>
                            </div>
                        </div>
                    </form>

                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
    <script>
        $(document).ready(function() {
            $('#eye-button-1').click(function() {
                $('#password').attr('type', $('#password').is(':password') ? 'text' : 'password');
                $(this).find('i').toggleClass('ph-eye-slash ph-eye');
            });
            $('#eye-button-2').click(function() {
                $('#confirm_password').attr('type', $('#confirm_password').is(':password') ? 'text' :
                    'password');
                $(this).find('i').toggleClass('ph-eye-slash ph-eye');
            });
        });
    </script>


    <script>
        $('#register_as').on('change', function () {
            const selectedValue = $(this).val();
            const studentClass = "<?php echo e(old('student_class', $student->student_class)); ?>";

            $.ajax({
                url: '<?php echo e(route('get.classes')); ?>',
                type: 'POST',
                data: {
                    register_as: selectedValue,
                    _token: '<?php echo e(csrf_token()); ?>'
                },
                success: function (response) {
                    $('#error-message').hide(); // Hide error message on success
                    const classDropdown = $('#student_class');
                    classDropdown.empty();
                    classDropdown.append('<option value="">Select Student Class</option>');

                    $.each(response, function (key, value) {
                        classDropdown.append('<option value="' + key + '">' + value + '</option>');
                    });

                    // Set the selected class in edit mode
                    if (studentClass) {
                        classDropdown.val(studentClass);
                    }
                },
                error: function () {
                    $('#error-message').text('Failed to load classes. Please try again.').show();
                }
            });
        });

    </script>
    <script>
        $(document).ready(function() {
            // This is to load cities for the selected country when editing
            var selectedCountryId = '<?php echo e($selectedCountryId ?? ''); ?>'; // Laravel variable passed to view
            var selectedCityId = '<?php echo e($selectedCityId ?? ''); ?>'; // Laravel variable passed to view

            if (selectedCountryId) {
                loadCities(selectedCountryId, selectedCityId); // Load cities based on the selected country
            }

            // When the country is selected
            $('#country_id').change(function() {
                var countryId = $(this).val();  // Get the selected country id
                if (countryId) {
                    loadCities(countryId); // Load cities when a country is selected
                } else {
                    $('#city_id').empty();
                    $('#city_id').append('<option value="">Select City</option>');
                }
            });

            // Function to load cities
            function loadCities(countryId, selectedCityId = null) {
                $.ajax({
                    url: "<?php echo e(route('get.cities')); ?>", // Your AJAX route
                    type: 'POST',
                    data: {
                        _token: '<?php echo e(csrf_token()); ?>',  // CSRF token
                        country_id: countryId
                    },
                    success: function(data) {
                        $('#city_id').empty();
                        $('#city_id').append('<option value="">Select City</option>');
                        $.each(data, function(key, city) {
                            var selected = (selectedCityId && selectedCityId == city.id) ? 'selected' : '';
                            $('#city_id').append('<option value="' + city.id + '" ' + selected + '>' + city.name + '</option>');
                        });
                    },
                    error: function(xhr, status, error) {
                        console.log("Error: " + error);  // Handle errors
                    }
                });
            }
        });
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('admin.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\freelanc\psychology_new\resources\views/admin/student/edit.blade.php ENDPATH**/ ?>