<?php if(count($faculty) > 0): ?>
    <?php $__currentLoopData = $faculty; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $faculties): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td><?php echo e($faculties->name ?? 'N/A'); ?></td>
            <td><?php echo e($faculties->email ?? 'N/A'); ?></td>
            <td><?php echo e($faculties->phone ?? 'N/A'); ?></td>
            <td><?php echo e($faculties->city ? $faculties->city->name : 'N/A'); ?></td>
            <td><?php echo e($faculties->country ? $faculties->country->name : 'N/A'); ?></td>
            <td><?php echo e($faculties->address ?? 'N/A'); ?></td>

            <td>
                
                <?php echo e(config('class.fuclaty_degree')[$faculties->degree] ?? 'N/A'); ?>

            </td>

            
            <td>
                <div class="button-switch">
                    <input type="checkbox" id="switch-<?php echo e($faculties->id); ?>" class="switch toggle-class"
                        data-id="<?php echo e($faculties->id); ?>" <?php echo e($faculties->status ? 'checked' : ''); ?> />
                    <label for="switch-<?php echo e($faculties->id); ?>" class="lbl-off"></label>
                    <label for="switch-<?php echo e($faculties->id); ?>" class="lbl-on"></label>
                </div>
            </td>
            <td>
                <div class="edit-1 d-flex align-items-center justify-content-center">
                    <a title="View Faculty" href="<?php echo e(route('faculty.show', $faculties->id)); ?>">
                        <span class="edit-icon"><i class="ph ph-eye"></i></span>
                    </a>

                    <a title="Edit Faculty" href="<?php echo e(route('faculty.edit', $faculties->id)); ?>">
                        <span class="edit-icon"><i class="ph ph-pencil-simple"></i></span>
                    </a>
                    <a title="Delete Faculty" data-route="<?php echo e(route('faculty.delete', $faculties->id)); ?>"
                        href="javascript:void(0);" id="delete">
                        <span class="trash-icon"><i class="ph ph-trash"></i></span>
                    </a>
                </div>
            </td>
        </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    
    <?php if($faculty->hasPages()): ?>
        <tr>
            <td colspan="12">
                <div class="d-flex justify-content-center">
                    <?php echo $faculty->links(); ?>

                </div>
            </td>
        </tr>
    <?php endif; ?>
<?php else: ?>
    <tr>
        <td colspan="12" class="text-center">No Data Found</td>
    </tr>
<?php endif; ?>
<?php /**PATH C:\xampp\htdocs\freelanc\psychology_new\resources\views/admin/faculty/table.blade.php ENDPATH**/ ?>