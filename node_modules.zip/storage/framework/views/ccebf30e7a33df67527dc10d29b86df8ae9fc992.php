
<?php $__env->startSection('content'); ?>
    <section>
        <div class="boxArea-4">
            <div class="container">
                <div class="row justify-content-center">
                    <div class="col-md-6 text-center">
                        <div class="text-center py-4"><img src="<?php echo e(asset('client_assets/img/boxArea-4/e1.png')); ?>" width="150"></div>
                        <h3>Email Confirmed</h3>
                        <h5>Thanks for confirming your email address.<br>let's start learning!</h5>
                        <div class="text-center">
                            
                            <?php if($type == 'teacher'): ?>
                            <a href="<?php echo e(route('front.faculty_login')); ?>" class="btn ton-btn w-50">Start</a>

                            <?php else: ?>
                            <a href="<?php echo e(route('front.student_login')); ?>" class="btn ton-btn w-50">Start</a>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            </div>
    </section>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('frontend.layouts.frontend_app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\freelanc\psychology_new\resources\views/frontend/email_confirmation.blade.php ENDPATH**/ ?>