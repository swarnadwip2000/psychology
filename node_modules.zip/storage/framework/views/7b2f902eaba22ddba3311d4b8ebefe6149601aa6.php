
<?php $__env->startSection('title'); ?>
    <?php echo e(env('APP_NAME')); ?> | Create Faculty
<?php $__env->stopSection(); ?>
<?php $__env->startPush('styles'); ?>
<?php $__env->stopPush(); ?>
<?php $__env->startSection('head'); ?>
    Create Faculty
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="main-content">
        <div class="inner_page">
            <div class="card search_bar sales-report-card">
                <div class="sales-report-card-wrap">
                    <div class="form-head">
                        <h4>Login Information</h4>
                    </div>
                    <form action="<?php echo e(route('faculty.store')); ?>" method="post" enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>
                        <div class="row justify-content-between">
                            <div class="col-md-6">
                                <div class="form-group-div">
                                    <div class="form-group">
                                        <label for="floatingInputValue">Email Address*</label>
                                        <input type="text" class="form-control" id="floatingInputValue" name="email"
                                            value="<?php echo e(old('email')); ?>" placeholder="Email Address*">
                                        <?php if($errors->has('email')): ?>
                                            <div class="error" style="color:red;"><?php echo e($errors->first('email')); ?></div>
                                        <?php endif; ?>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group-div">
                                    <div class="form-group">
                                        <label for="floatingInputValue">Mobile*</label>
                                        <input type="text" class="form-control" id="floatingInputValue" name="phone"
                                            value="<?php echo e(old('phone')); ?>" placeholder="Mobile*">
                                        <?php if($errors->has('phone')): ?>
                                            <div class="error" style="color:red;"><?php echo e($errors->first('phone')); ?></div>
                                        <?php endif; ?>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group-div">
                                    <div class="form-group">
                                        <label for="floatingInputValue">Password*</label>
                                        <input type="password" class="form-control" id="password" name="password"
                                            value="<?php echo e(old('password')); ?>" placeholder="Password*">
                                        <span class="eye-btn-1" id="eye-button-1">
                                            <i class="ph ph-eye-slash" aria-hidden="true" id="togglePassword"></i>
                                        </span>
                                        <?php if($errors->has('password')): ?>
                                            <div class="error" style="color:red;"><?php echo e($errors->first('password')); ?></div>
                                        <?php endif; ?>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group-div">
                                    <div class="form-group">
                                        <label for="floatingInputValue">Confirm Password*</label>
                                        <input type="password" class="form-control" id="confirm_password"
                                            name="confirm_password" value="<?php echo e(old('confirm_password')); ?>"
                                            placeholder="Confirm Password*">
                                        <span class="eye-btn-1" id="eye-button-2">
                                            <i class="ph ph-eye-slash" aria-hidden="true" id="togglePassword"></i>
                                        </span>
                                        <?php if($errors->has('confirm_password')): ?>
                                            <div class="error" style="color:red;">
                                                <?php echo e($errors->first('confirm_password')); ?></div>
                                        <?php endif; ?>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div class="sales-report-card-wrap mt-5">
                            <div class="form-head">
                                <h4>Personal Information</h4>
                            </div>

                            <div class="row">
                                <div class="col-xl-4 col-md-6">
                                    <div class="form-group-div">
                                        <div class="form-group">
                                            <label for="floatingInputValue">Full Name*</label>
                                            <input type="text" class="form-control" id="floatingInputValue"
                                                name="name" value="<?php echo e(old('name')); ?>" placeholder="Full Name*">
                                            <?php if($errors->has('name')): ?>
                                                <div class="error" style="color:red;"><?php echo e($errors->first('name')); ?></div>
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                </div>

                                
                                <div class="col-xl-4 col-md-6">
                                    <div class="form-group-div">
                                        <div class="form-group">
                                            <label for="floatingInputValue">Country*</label>
                                            <select id="country_id" name="country_id" class="form-control">
                                                <option value="">Select Country</option>
                                                <?php $__currentLoopData = $countries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $country): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <option value="<?php echo e($country->id); ?>"><?php echo e($country->name); ?></option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </select>
                                            <?php if($errors->has('country_id')): ?>
                                                <div class="error" style="color:red;"><?php echo e($errors->first('country_id')); ?>

                                                </div>
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-xl-4 col-md-6">
                                    <div class="form-group-div">
                                        <div class="form-group">
                                            <label for="floatingInputValue">City*</label>
                                            <select id="city_id" name="city_id" class="form-control">
                                                <option value="">Select City</option>
                                                
                                            </select>
                                            <?php if($errors->has('city_id')): ?>
                                                <div class="error" style="color:red;"><?php echo e($errors->first('city_id')); ?>

                                                </div>
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="form-group-div">
                                        <div class="form-group">
                                            <label for="floatingInputValue">Address*</label>
                                            <input type="text" class="form-control" id="floatingInputValue"
                                                name="address" value="<?php echo e(old('address')); ?>" placeholder="Address*">
                                            <?php if($errors->has('address')): ?>
                                                <div class="error" style="color:red;"><?php echo e($errors->first('address')); ?>

                                                </div>
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                </div>
                                
                                


                                <div class="col-xl-6 col-md-6">
                                    <div class="form-group-div">
                                        <div class="form-group">
                                            <label for="floatingInputValue">Degree*</label>
                                            <select name="degree" id="degree" class="form-control">
                                                <option value="">Select Degree</option>
                                                <?php $__currentLoopData = config('class.fuclaty_degree'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <option value="<?php echo e($key); ?>"
                                                        <?php echo e(old('degree') == $key ? 'selected' : ''); ?>>
                                                        <?php echo e($val); ?>

                                                    </option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </select>
                                            <?php if($errors->has('degree')): ?>
                                                <div class="error" style="color:red;">
                                                    <?php echo e($errors->first('degree')); ?>

                                                </div>
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                </div>

                                

                                <div class="col-xl-6 col-md-6">
                                    <div class="form-group-div">
                                        <div class="form-group">
                                            <label for="floatingInputValue">Status*</label>
                                            <select name="status" id="status" class="form-control">
                                                <option value="">Select Status</option>
                                                <option value="1" <?php echo e(old('status') == 1 ? 'selected' : ''); ?>>Active
                                                </option>
                                                <option value="0" <?php echo e(old('status') == 0 ? 'selected' : ''); ?>>Inactive
                                                </option>
                                            </select>
                                            <?php if($errors->has('status')): ?>
                                                <div class="error" style="color:red;"><?php echo e($errors->first('status')); ?>

                                                </div>
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                </div>

                                <div class="col-xl-12">
                                    <div class="btn-1">
                                        <button type="submit">Create</button>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
    <script>
        $(document).ready(function() {
            $('#eye-button-1').click(function() {
                $('#password').attr('type', $('#password').is(':password') ? 'text' : 'password');
                $(this).find('i').toggleClass('ph-eye-slash ph-eye');
            });
            $('#eye-button-2').click(function() {
                $('#confirm_password').attr('type', $('#confirm_password').is(':password') ? 'text' :
                    'password');
                $(this).find('i').toggleClass('ph-eye-slash ph-eye');
            });
        });
    </script>

    <script>
        $(document).ready(function() {
            // When the country is selected
            $('#country_id').change(function() {
                var countryId = $(this).val();  // Get the selected country id
                if (countryId) {
                    // Make an Ajax POST request to fetch cities based on country id
                    $.ajax({
                        url: "<?php echo e(route('get.cities')); ?>", // The URL where the POST request will be sent
                        type: 'POST',
                        data: {
                            _token: '<?php echo e(csrf_token()); ?>',  // CSRF token for Laravel
                            country_id: countryId
                        },
                        success: function(data) {
                            // If cities are returned, populate the city dropdown
                            $('#city_id').empty();  // Clear previous options
                            $('#city_id').append('<option value="">Select City</option>');  // Default option
                            $.each(data, function(key, city) {
                                $('#city_id').append('<option value="' + city.id + '">' + city.name + '</option>');
                            });
                        },
                        error: function(xhr, status, error) {
                            console.log("Error: " + error);  // Handle error
                        }
                    });
                } else {
                    // If no country is selected, clear the city dropdown
                    $('#city_id').empty();
                    $('#city_id').append('<option value="">Select City</option>');
                }
            });
        });
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('admin.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\freelanc\psychology_new\resources\views/admin/faculty/create.blade.php ENDPATH**/ ?>