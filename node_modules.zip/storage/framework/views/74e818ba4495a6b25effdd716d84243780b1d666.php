<?php if(count($students) > 0): ?>
    <?php $__currentLoopData = $students; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $student): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td><?php echo e($student->name ?? 'N/A'); ?></td>
            <td><?php echo e($student->email ?? 'N/A'); ?></td>
            <td><?php echo e($student->phone ?? 'N/A'); ?></td>
            <td><?php echo e($student->city ? $student->city->name : 'N/A'); ?></td>
            <td><?php echo e($student->country ? $student->country->name : 'N/A'); ?></td>
            <td><?php echo e($student->address ?? 'N/A'); ?></td>
            <td><?php echo e($student->student_age ?? 'N/A'); ?></td>
            <td>
                
                <?php echo e(config('class.school_class')[$student->student_class] ?? 'N/A'); ?>

            </td>
            <td><?php echo e($student->institute_name ?? 'N/A'); ?></td>
            <td>
                <?php
                    $registerAsLabels = [1 => 'School', 2 => 'College', 3 => 'Other'];
                ?>
                <?php echo e($registerAsLabels[$student->register_as] ?? 'N/A'); ?>

            </td>
            <td>
                <div class="button-switch">
                    <input type="checkbox" id="switch-<?php echo e($student->id); ?>" class="switch toggle-class"
                        data-id="<?php echo e($student->id); ?>" <?php echo e($student->status ? 'checked' : ''); ?> />
                    <label for="switch-<?php echo e($student->id); ?>" class="lbl-off"></label>
                    <label for="switch-<?php echo e($student->id); ?>" class="lbl-on"></label>
                </div>
            </td>
            <td>
                <div class="edit-1 d-flex align-items-center justify-content-center">
                    <a title="Edit Student" href="<?php echo e(route('students.edit', $student->id)); ?>">
                        <span class="edit-icon"><i class="ph ph-pencil-simple"></i></span>
                    </a>
                    <a title="Delete Student" data-route="<?php echo e(route('students.delete', $student->id)); ?>"
                        href="javascript:void(0);" id="delete">
                        <span class="trash-icon"><i class="ph ph-trash"></i></span>
                    </a>
                </div>
            </td>
        </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    
    <?php if($students->hasPages()): ?>
        <tr>
            <td colspan="12">
                <div class="d-flex justify-content-center">
                    <?php echo $students->links(); ?>

                </div>
            </td>
        </tr>
    <?php endif; ?>
<?php else: ?>
    <tr>
        <td colspan="12" class="text-center">No Data Found</td>
    </tr>
<?php endif; ?>
<?php /**PATH C:\xampp\htdocs\freelanc\psychology_new\resources\views/admin/student/table.blade.php ENDPATH**/ ?>