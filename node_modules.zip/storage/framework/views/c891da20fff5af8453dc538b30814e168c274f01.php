<?php $__env->startSection('title'); ?>
    All Meeting Details - <?php echo e(env('APP_NAME')); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startPush('styles'); ?>
    <style>
        .dataTables_filter {
            margin-bottom: 10px !important;
        }
    </style>
<?php $__env->stopPush(); ?>
<?php $__env->startSection('head'); ?>
    All Meeting Details
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <section id="loading">
        <div id="loading-content"></div>
    </section>
    <div class="main-content">
        <div class="inner_page">

            <div class="card table_sec stuff-list-table">
                <div class="row">
                    <div class="col-md-12">
                        <div class="card">
                            <div class="card-header d-flex justify-content-between">
                                <div class="header-title">
                                    <h4 class="card-title">Upcoming Meeting</h4>
                                </div>
                            </div>
                            <div class="card-body table-fixed p-0">
                                <div class="table-responsive mt-4">
                                    <table id="basic-table" class="table table-striped mb-0" role="grid">
                                        <thead>
                                            <tr>
                                                <th>Topic</th>
                                                <th>Student Name</th>
                                                <th>Date (mm-dd-yyy)</th>
                                                <th>Time</th>
                                                <th>Metting Id</th>
                                                <th>Metting Password</th>
                                                <th>Action</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php $__currentLoopData = $booking_slot; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $booking): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <tr>
                                                    <td>
                                                        <?php echo e($booking->slot->topic); ?>

                                                    </td>
                                                    <td>
                                                        <?php echo e($booking->student->name); ?>

                                                    </td>
                                                    <td>
                                                        <?php echo e(date('m-d-Y', strtotime($booking->date))); ?>

                                                    </td>
                                                    <td> <?php echo e(date('H:i A', strtotime($booking->time))); ?></td>

                                                    <td><?php echo e($booking->zoom_id ?? 'N/A'); ?></td>

                                                    <td>
                                                        <?php echo e(json_decode($booking->zoom_response)->password ?? 'N/A'); ?>

                                                    </td>
                                                    <td>
                                                        <?php if($booking->zoom_id && $booking->meeting_status != 2): ?>
                                                            <!-- If the meeting is ongoing (meeting_status != 2), show 'End Call' -->
                                                            <a href="<?php echo e(json_decode($booking->zoom_response)->join_url ?? 'N/A'); ?>"
                                                            class="btn btn-success" target="_blank">Join Now</a>
                                                            <a href="javascript:void(0)"
                                                                onclick="endMeeting(<?php echo e($booking->id); ?>)"
                                                                class="btn btn-danger">

                                                                End Call
                                                            </a>
                                                        <?php elseif($booking->zoom_id && $booking->meeting_status == 2): ?>
                                                            <!-- If the meeting is ended (meeting_status == 2), show 'Meeting Ended' or something else -->
                                                            <span class="btn btn-secondary" disabled>Meeting Ended</span>
                                                        <?php else: ?>
                                                            <!-- If there's no Zoom meeting yet (no zoom_id), show 'Start Call' -->
                                                            <a href="javascript:void(0)"
                                                                onclick="getbookingTime(<?php echo e($booking->id); ?>)"
                                                                class="btn btn-success">
                                                                Start Call
                                                            </a>
                                                        <?php endif; ?>
                                                    </td>

                                                </tr>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="col-md-12 mt-5">
                        <div class="card">
                            <div class="card-header d-flex justify-content-between">
                                <div class="header-title">
                                    <h4 class="card-title">Past Meeting History</h4>
                                </div>
                            </div>
                            <div class="card-body table-fixed p-0">
                                <div class="table-responsive mt-4">
                                    <table id="basic-table" class="table table-striped mb-0" role="grid">
                                        <thead>
                                            <tr>
                                                <th>Topic</th>
                                                <th>Student Name</th>
                                                <th>Date (mm-dd-yyyy)</th>
                                                <th>Start Time</th>
                                                <th>End Time</th>
                                                <th>Duration</th> <!-- New column for meeting duration -->
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php $__currentLoopData = $booking_history; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $meeting): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <tr>
                                                    <td><?php echo e($meeting->slot->topic ?? ''); ?></td>
                                                    <td><?php echo e($meeting->student->name ?? ''); ?></td>
                                                    <td><?php echo e(date('m-d-Y', strtotime($meeting->date))); ?></td>
                                                    <td><?php echo e($meeting->meeting_start_time ? date('H:i A', strtotime($meeting->meeting_start_time)) : 'N/A'); ?></td>
                                                    <td><?php echo e($meeting->meeting_end_time ? date('H:i A', strtotime($meeting->meeting_end_time)) : 'N/A'); ?></td>
                                                    <td>
                                                        <?php if($meeting->meeting_start_time && $meeting->meeting_end_time): ?>
                                                            <?php
                                                                // Calculate duration using Carbon
                                                                $start = \Carbon\Carbon::parse($meeting->meeting_start_time);
                                                                $end = \Carbon\Carbon::parse($meeting->meeting_end_time);
                                                                $duration = $start->diff($end); // Get the difference between start and end times
                                                            ?>
                                                            <?php echo e($duration->format('%h hours %i minutes')); ?> <!-- Format the duration as hours and minutes -->
                                                        <?php else: ?>
                                                            N/A
                                                        <?php endif; ?>
                                                    </td>
                                                </tr>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </tbody>
                                    </table>

                                    <!-- Pagination Links -->
                                    <div class="pagination-container mt-2 d-flex justify-content-center">
                                        <?php echo e($booking_history->links()); ?>

                                    </div>

                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('admin.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\freelanc\psychology_new\resources\views/admin/faculty/view.blade.php ENDPATH**/ ?>