<footer class="main-footer">
    <div class="footer-left">
        Copyright © <?php echo e(date('Y')); ?>

        <div class="bullet"></div>
        <a target="_blank" href=""></a>
    </div>
    <div class="footer-right"></div>
</footer>
<?php /**PATH C:\xampp\htdocs\freelanc\psychology_new\resources\views/admin/includes/footer.blade.php ENDPATH**/ ?>