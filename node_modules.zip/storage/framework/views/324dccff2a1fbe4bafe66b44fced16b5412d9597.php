<?php $__env->startSection('title'); ?>
    Dashboard - <?php echo e(env('APP_NAME')); ?> admin
<?php $__env->stopSection(); ?>
<?php $__env->startPush('styles'); ?>
<?php $__env->stopPush(); ?>
<?php $__env->startSection('head'); ?>
    Dashboard
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="main-content" style="min-height: 842px;">

        <div class="dashboard_tab pt-5 pl-0 pb-5 pl-sm-5">
            <!-- Nav tabs -->

            <div class="">

                
            </div>



        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('admin.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\freelanc\psychology_new\resources\views/admin/dashboard.blade.php ENDPATH**/ ?>