<?php $__env->startSection('content'); ?>

  <section class="dshboard" style="height: 750px">
  <div class="dshboard-contain">
    <div class="container">
      <div class="row">
        <div class="col-md-12">
          <h5 class="video-heading">Live Video Tutorial</h5>

            <iframe src="<?php echo e("https://zoom.us/wc/".$meeting->zoom_id."/join?pwd=".$meeting->password."&un='sankar Bera'&prefer=1"); ?>"   allowfullscreen="false"
                frameborder="0" width="100%" height="500px"></iframe>

        </div>
        
        </div>
        <br>
      </div>
  </div>
  </div>
</section>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('frontend.layouts.teacher_app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\freelanc\psychology_new\resources\views/frontend/teacher/live_class.blade.php ENDPATH**/ ?>