<?php $__env->startSection('content'); ?>
    <section>
        <div class="boxArea-3">
            <div class="container">
                <div class="row justify-content-center">
                    <div class="col-md-8 text-center">
                        <h3>Welcome to the class of <span>Psychology</span></h3>
                        <h5>Thanks for joining us ! <span>Kindly confirm your email by clicking on the Button.</span> </h5>

                        <div class="text-center">
                            <a href="<?php echo e(route('front.email_confirmation')); ?>" class="btn ton-btn">Confirm my email</a>

                            <p class="mt-3 last">Please confirm your account by clicking on the link we've just sent to the
                                email address provided. </p>
                        </div>
                    </div>
                </div>
            </div>
    </section>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('frontend.layouts.frontend_app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\freelanc\psychology_new\resources\views/frontend/email_verification.blade.php ENDPATH**/ ?>