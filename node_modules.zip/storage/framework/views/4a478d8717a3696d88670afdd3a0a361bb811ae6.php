<?php $__env->startSection('content'); ?>
    <section class="dshboard" style="height: 750px">
        <div class="dshboard-contain">
            <div class="container">
                <div class="row">
                    <div class="col-md-12">
                        <h5 class="video-heading">Live Video Tutorial</h5>
                        
                        <div id="zmmtg-root"></div>
                    </div>
                    
                </div>
                <br>
            </div>
        </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
    <script>
        setTimeout(() => {
            $(document).on('click', '.leave-meeting-options__btn', function() {
                alert('Button clicked!');
            });
        }, 1500);
        // Use event delegation to listen for clicks on dynamically added elements
    </script>
    <!-- Dependencies for client view and component view -->
    <script src="https://source.zoom.us/2.7.0/lib/vendor/react.min.js"></script>
    <script src="https://source.zoom.us/2.7.0/lib/vendor/react-dom.min.js"></script>
    <script src="https://source.zoom.us/2.7.0/lib/vendor/redux.min.js"></script>
    <script src="https://source.zoom.us/2.7.0/lib/vendor/redux-thunk.min.js"></script>
    <script src="https://source.zoom.us/2.7.0/lib/vendor/lodash.min.js"></script>

    <!-- Choose between the client view or component view: -->
    <script src="https://source.zoom.us/zoom-meeting-2.7.0.min.js"></script>

    
    <script>
        ZoomMtg.preLoadWasm();
        ZoomMtg.prepareWebSDK();

        var accessToken = "<?php echo e($outhtoken); ?>";
        var meetingNumber = "<?php echo e($meetingNumber); ?>";
        var passWord = "<?php echo e($password); ?>";
        var userName ="<?php echo e($userName); ?>";
        var sdkKey = "rCGqfQmuXtjkgAHwjrw";
        var signature = "<?php echo e($signature); ?>";
        // var signature = "<?php echo e($signature); ?>";
        ZoomMtg.init({
            leaveUrl: "https://example.com/thanks-for-joining",
            success: () => {
                ZoomMtg.join({
                    sdkKey: sdkKey,
                    signature: signature,
                    meetingNumber: meetingNumber,
                    passWord: passWord,
                    userName: userName,
                    zak: accessToken, // Use the OAuth access token here
                    // signature: signature,
                    success: (success) => {
                        console.log("Join success:", success);
                    },
                    error: (error) => {
                        console.log("Join error:", error);
                    }
                });
            },
            error: (error) => {
                console.log("Init error:", error);
            }
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('frontend.layouts.student_app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\freelanc\psychology_new\resources\views/frontend/student/live_class.blade.php ENDPATH**/ ?>