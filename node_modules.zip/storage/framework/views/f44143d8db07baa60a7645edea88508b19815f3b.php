
<?php $__env->startSection('content'); ?>
    <section class="boxArea" style="min-height: 580px; height: auto;">
        <div class="container">
            <h4 class="page-head text-center mb-5"> Enter your details</h4>
            <div class="row">
                <div class="col-md-12">
                    <div class="row justify-content-center">
                        <form action="<?php echo e(route('front.registration_success')); ?>" method="POST" onsubmit="return valid()">
                            <input type="hidden" name="register_as" value="1">
                            <?php echo csrf_field(); ?>
                            <div class="row">
                                <div class="form-group col-md-6">
                                    <label for="student_age">Age</label>
                                    <select id="student_age" name="student_age" class="form-control">
                                        <option value="">Select</option>
                                        <?php for($i = 20; $i < 45; $i++): ?>
                                            <option value="<?php echo e($i); ?>"><?php echo e($i); ?></option>
                                        <?php endfor; ?>
                                    </select>
                                </div>

                                <div class="form-group col-md-6">
                                    <label for="student_class">Class</label>
                                    <select id="student_class" name="student_class" class="form-control">
                                        <option value="">Select</option>
                                        <?php $__currentLoopData = config('class.school_class'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($key); ?>"><?php echo e($val); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>

                                <div class="form-group col-md-6">
                                    <label for="country_name">Country Name</label>
                                    <select id="country_name" name="country_name" class="form-control">
                                        <option selected>Select</option>
                                        <option value="">Select</option>
                                        <?php $__currentLoopData = $countries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($val->id); ?>"
                                                <?php echo e(old('country_name') == $val->id ? 'selected' : ''); ?>><?php echo e($val->name); ?>

                                            </option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>

                                <div class="form-group col-md-6">
                                    <label for="city_name">City</label>
                                    <select id="city_name" name="city_name" class="form-control">
                                        <option selected>Select</option>
                                        <?php $__currentLoopData = $city; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $val): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($val->id); ?>"><?php echo e($val->name); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>
                            </div>

                            <div class="form-group">
                                <label for="school_name">School Name</label>
                                <input type="text" class="form-control" id="school_name" name="school_name"
                                    placeholder="School Name">
                            </div>
                            <div class="col-md-12 text-center">
                                <input type="submit" class="btn btn-info" value="Next" />
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
    <script>
        function valid() {
            if ($("#student_age").val() == '') {
                toastr.error('Enter your age!!');
                return false;
            } else if ($("#student_class").val() == '') {
                toastr.error('Enter your class!!');
                return false;
            } else if ($("#country_name").val() == '') {
                toastr.error('Enter your country name!!');
                return false;
            } else if ($("#city_name").val() == '') {
                toastr.error('Enter your city name!!');
                return false;
            } else if ($("#school_name").val() == '') {
                toastr.error('Enter your school name!!');
                return false;
            }


        }
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('frontend.layouts.frontend_app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\freelanc\psychology_new\resources\views/frontend/school_registration.blade.php ENDPATH**/ ?>