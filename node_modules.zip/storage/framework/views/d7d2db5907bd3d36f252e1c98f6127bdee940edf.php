<?php $__env->startSection('content'); ?>
    <section class="boxArea" style="min-height: 580px; height: auto;">
        <div class="container">
            <h4 class="page-head text-center mb-5"> Enter your details</h4>
            <div class="row">
                <div class="col-md-12">
                    <div class="row justify-content-center">
                        <form action="<?php echo e(route('front.faculty_login')); ?>" method="POST" onsubmit="return valid()">
                            <?php echo csrf_field(); ?>
                            <div class="row">
                                <div class="form-group col-md-12">
                                    <span class="text-success"><?php echo e(Session::get('successmsg')); ?></span>
                                    <span class="text-danger"><?php echo e(Session::get('errmsg')); ?></span>
                                    </div>
                                <div class="form-group col-md-6">
                                    <label for="student_class">Registered Email ID</label>
                                    <input type="text" class="form-control" id="email" name="email" placeholder="Email Address">
                                </div>
                                <div class="form-group col-md-6">
                                    <label for="city_name">Enter Password</label>
                                    <input type="password" class="form-control" id="password" name="password" placeholder="Password">
                                </div>
                            </div>
                            <div class="col-md-12 text-center">
                                <span>Create a New Account <a href="<?php echo e(route('front.faculty_registration')); ?>">Click Here</a></span>
                                <br/>
                                <input type="submit" class="btn btn-info" value="Login" />
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
    <script>
        function valid() {
            if($("#email").val() == ''){
                toastr.error('Enter your email id!!');
                return false;
            }else if($("#password").val() == ''){
                toastr.error('Enter your password!!');
                return false;
            }
        }
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('frontend.layouts.frontend_app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\freelanc\psychology_new\resources\views/frontend/faculty_login.blade.php ENDPATH**/ ?>