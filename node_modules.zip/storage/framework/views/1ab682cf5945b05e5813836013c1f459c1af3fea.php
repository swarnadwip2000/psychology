<!DOCTYPE html>
<html lang="en" data-layout="vertical" data-topbar="light" data-sidebar="dark" data-sidebar-size="lg"
    data-sidebar-image="none">

<head>
    <meta content="width=device-width,  initial-scale=1,  maximum-scale=1,  shrink-to-fit=no" name="viewport" />
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>" />
    <title>Admin Login</title>
    <link rel="stylesheet" href="<?php echo e(asset('admin_assets/bootstrap-5.3/css/bootstrap.min.css')); ?>">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@100;200;300;400;500;600;700&display=swap"
        rel="stylesheet">
    <script src="https://unpkg.com/phosphor-icons"></script>
    <!-- <link rel="stylesheet" href="css/bootstrap.min.css" /> -->
    <link rel="stylesheet" href="<?php echo e(asset('admin_assets/css/app.min.css')); ?>" />
    <link rel="stylesheet" href="<?php echo e(asset('admin_assets/css/custom.css')); ?>" />
    <link rel="stylesheet" href="<?php echo e(asset('admin_assets/css/style.css')); ?>" />

    <link rel="stylesheet" href="<?php echo e(asset('admin_assets/css/morris.css')); ?>">
    <link rel="stylesheet" type="text/css"
        href="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/toastr.min.css">
    <link rel="stylesheet" href="https://cdn.datatables.net/1.13.2/css/jquery.dataTables.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/limonte-sweetalert2/7.2.0/sweetalert2.min.css">
</head>

<body class="account-page">

    <div class="main-wrapper">
        <div class="account-content">
            <div class="container">

                <div class="account-logo">
                    <a href="admin-dashboard.html"><img src="<?php echo e(asset('client_assets/img/logo/logo.jpg')); ?>"
                            alt="Dreamguy's Technologies"></a>
                </div>

                <div class="account-box">
                    <div class="account-wrapper">
                        <h3 class="account-title">Login</h3>
                        <p class="account-subtitle">Access to our dashboard</p>

                        <form action="<?php echo e(route('admin.login.check')); ?>" method="POST">
                            <?php echo csrf_field(); ?>
                            <div class="form-group">
                                <label>Email Address</label>
                                <input type="email" class="form-control" name="email" id="inputEmailAddress"
                                    placeholder="Email Address">
                                <?php if($errors->has('email')): ?>
                                    <div class="error" style="color:red;"><?php echo e($errors->first('email')); ?></div>
                                <?php endif; ?>
                            </div>
                            <div class="form-group">
                                <div class="row">
                                    <div class="col">
                                        <label>Password</label>
                                    </div>
                                    
                                </div>
                                <div class="position-relative" id="show_hide_password">
                                    <input type="password" class="form-control border-end-0" name="password"
                                        id="inputChoosePassword" placeholder="Enter Password">
                                    <a href="javascript:;" class=""><span class="ph ph-eye-slash"
                                            id="toggle-password"></span></a>
                                </div>
                                <?php if($errors->has('password')): ?>
                                    <div class="error" style="color:red;"><?php echo e($errors->first('password')); ?>

                                    </div>
                                <?php endif; ?>
                            </div>
                            <div class="form-group text-center">
                                <button class="btn btn-primary account-btn" type="submit">Login</button>
                            </div>
                            <div class="account-footer">
                                <p><a href="<?php echo e(route('admin.forget.password.show')); ?>">Forgot Password?</a></p>
                            </div>
                        </form>

                    </div>
                </div>
            </div>
        </div>

    </div>


</body>

<script src="<?php echo e(asset('admin_assets/js/jquery-3.4.1.min.js')); ?>"></script>
<!-- <script src="js/jquery.min.js"></script> -->
<!-- <script src="//ajax.googleapis.com/ajax/libs/jquery/1.9.0/jquery.min.js"></script> -->
<!-- <script src="js/bootstrap.min.js" async=""></script> -->
<script src="<?php echo e(asset('admin_assets/bootstrap-5.3/js/bootstrap.min.js')); ?>"></script>
<script src="<?php echo e(asset('admin_assets/js/raphael-min.js')); ?>"></script>
<script src="<?php echo e(asset('admin_assets/js/morris.min.js')); ?>"></script>
<script src="<?php echo e(asset('admin_assets/js/Chart.min.js')); ?>"></script>
<script src="<?php echo e(asset('admin_assets/js/custom.js')); ?>" async=""></script>
<script src="<?php echo e(asset('admin_assets/js/app.min.js')); ?>"></script>
<script src="<?php echo e(asset('admin_assets/js/scripts.js')); ?>" async=""></script>
<script src="<?php echo e(asset('admin_assets/js/jquery-ui.min.js')); ?>"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/js/toastr.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/latest/js/toastr.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery-validate/1.19.2/jquery.validate.min.js"></script>
<script src="https://cdn.datatables.net/1.13.2/js/jquery.dataTables.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/limonte-sweetalert2/7.2.0/sweetalert2.all.min.js"></script>
<script>
    <?php if(Session::has('message')): ?>
        toastr.options = {
            "closeButton": true,
            "progressBar": true
        }
        toastr.success("<?php echo e(session('message')); ?>");
    <?php endif; ?>

    <?php if(Session::has('error')): ?>
        toastr.options = {
            "closeButton": true,
            "progressBar": true
        }
        toastr.error("<?php echo e(session('error')); ?>");
    <?php endif; ?>

    <?php if(Session::has('info')): ?>
        toastr.options = {
            "closeButton": true,
            "progressBar": true
        }
        toastr.info("<?php echo e(session('info')); ?>");
    <?php endif; ?>

    <?php if(Session::has('warning')): ?>
        toastr.options = {
            "closeButton": true,
            "progressBar": true
        }
        toastr.warning("<?php echo e(session('warning')); ?>");
    <?php endif; ?>
</script>
<script>
    //
</script>

</html>
<?php /**PATH C:\xampp\htdocs\freelanc\psychology_new\resources\views/admin/auth/login.blade.php ENDPATH**/ ?>